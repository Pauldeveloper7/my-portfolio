export const products = [
    {
      title: "Scrapecart",
      thumbnail:
        '/images/scrapecart.png',
    },
    {
      title: "a-oneshop",
      thumbnail: "/images/aoneshop.png",
    },
    {
      title: "Footwear",
      thumbnail:
        "/images/responsive.png",
    },
   
    {
      title: "A-onefootwear",
    
      thumbnail:
        "/images/a-onefootwear.png",
    },
    {
      title: "Yoom ",
    
      thumbnail:
        "/images/yoom.png",
    },
    // {
    //   title: "Pixel Perfect",
      
    //   thumbnail:
    //     "https://aceternity.com/images/products/thumbnails/new/pixelperfect.png",
    // },
   
    // {
    //   title: "Algochurn",
      
    //   thumbnail:
    //     "https://aceternity.com/images/products/thumbnails/new/algochurn.png",
    // },
    // {
    //   title: "Aceternity UI",
    
    //   thumbnail:
    //     "https://aceternity.com/images/products/thumbnails/new/aceternityui.png",
    // },
    // {
    //   title: "Tailwind Master Kit",
    //   thumbnail:
    //     "https://aceternity.com/images/products/thumbnails/new/tailwindmasterkit.png",
    // },
    // {
    //   title: "SmartBridge",
    //   thumbnail:
    //     "https://aceternity.com/images/products/thumbnails/new/smartbridge.png",
    // },
    // {
    //   title: "Renderwork Studio",
    //   thumbnail:
    //     "https://aceternity.com/images/products/thumbnails/new/renderwork.png",
    // },
   
    // {
    //   title: "Creme Digital",
    //   thumbnail:
    //     "https://aceternity.com/images/products/thumbnails/new/cremedigital.png",
    // },
    // {
    //   title: "Golden Bells Academy",
    //   thumbnail:
    //     "https://aceternity.com/images/products/thumbnails/new/goldenbellsacademy.png",
    // },
    // {
    //   title: "Invoker Labs",
    
    //   thumbnail:
    //     "https://aceternity.com/images/products/thumbnails/new/invoker.png",
    // },
    // {
    //   title: "E Free Invoice",
    //   thumbnail:
    //     "https://aceternity.com/images/products/thumbnails/new/efreeinvoice.png",
    // },
  ];