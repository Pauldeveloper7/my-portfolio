const people = [
    {
      id: 1,
      name: "Framer-motion",
      image:'/images/reactjs.jpg'
    },
    {
      id: 2,
      name: " Framer-motion",
      image:
        "/images/framer-motion.png",
    },
    {
      id: 3,
      name: "python",
      image:
        "/images/python.png",
    },
    {
      id: 4,
      name: "MongoDB",
      image:
        "/images/mongodb.png",
    },
    {
      id: 5,
      name: "Next.js",
      image:
        "/images/nextjs.png",
    },
    {
      id: 6,
      name: "tailwind.js",
      image:
        "/images/tailwind.png",
    },
  ];
  export default people ;