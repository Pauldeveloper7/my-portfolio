/** @type {import('next').NextConfig} */
const nextConfig = {
        images: {
          domains: ['aceternity.com' ,'images.unsplash.com']
        
        },
        output: 'export'
    }
export default nextConfig;

